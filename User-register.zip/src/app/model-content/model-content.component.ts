import { Component, OnInit, Input } from '@angular/core';
// import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-model-content',
  templateUrl: './model-content.component.html',
  styleUrls: ['./model-content.component.css']
})
export class ModelContentComponent implements OnInit {

   @Input() public user;
  // @Output() passEntry: EventEmitter<any> = new EventEmitter();

  constructor(
    // public activeModal: NgbActiveModal
  ) { }

  ngOnInit() {
    console.log(this.user);
  }

  // passBack() {
  //   this.passEntry.emit(this.user);
  //   this.activeModal.close(this.user);
  // }

}
