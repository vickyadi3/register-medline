import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AlertService } from '../services/alert.service';
import { ModelContentComponent } from '../model-content/model-content.component';




@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

 registerForm: FormGroup;
    loading = false;
    submitted = false;
    display='none'; //default Variable
    public userModel = {
    fname: '',
    lname: '',
    phone: '',
    ext: '',
    email: ''
  }


    constructor(
        private formBuilder: FormBuilder,
        private router: Router,
        private alertService: AlertService,
    ) { }

  ngOnInit() {
        this.registerForm = this.formBuilder.group({
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            phone: ['', Validators.required],
            ext: [''],
            email: ['', [Validators.required]],
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    onSubmit() {
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
        console.log(this.registerForm.value);
       const data = this.registerForm.value;
            this.userModel.fname = data.firstName;
            this.userModel.lname = data.lastName;
            this.userModel.phone = data.phone;
            this.userModel.email = data.email;
    }

    thankYou() {
        this.router.navigate(['/thank-you']);
    }

 openModalDialog(){
    this.display='block'; //Set block css
 }

 closeModalDialog(){
  this.display='none'; //set none css after close dialog
 }



}
